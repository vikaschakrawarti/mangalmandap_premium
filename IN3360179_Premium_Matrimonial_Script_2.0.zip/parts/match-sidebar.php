				<ul class="my-match-aside mb-20 col-xs-16">
                	<li>
                    	<a href="one-way-matches"><i class="fas fa-long-arrow-alt-right gt-margin-right-10"></i><?php echo $lang['One Way Matches']; ?></a>
                    </li>
                    <li>
                    	<a href="two-way-matches"><i class="fas fa-exchange-alt gt-margin-right-10"></i><?php echo $lang['Two Way Matches']; ?></a>
                    </li>
                    <li>
                    	<a href="preferred-matches"><i class="fas fa-star gt-margin-right-10"></i><?php echo $lang['Preferred Matches']; ?></a>
                    </li>
                    <li>
                    	<a href="broader-matches"><i class="fa fa-arrows-alt gt-margin-right-10"></i><?php echo $lang['Broader Matches']; ?></a>
                    </li>
                    <li>
                    	<a href="custom-matches"><i class="fa fa-tasks gt-margin-right-10"></i><?php echo $lang['Custom Matches']; ?></a>
                    </li>
                </ul>
				