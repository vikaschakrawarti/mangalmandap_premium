<div class="gt-panel gt-panel-blue gt-spotlight gt-main-profile">
                     <div class="gt-panel-head">
                    	<div class="row">
                            <a href="" class="col-xxl-5 col-xl-5 col-lg-6 col-xs-16 text-center gt-spotlight-name">
                                <h4 class="gt-margin-top-0 gt-margin-bottom-0">
                                   Paul Walker <small class="">( GT1111 )</small>
                                </h4>
                            </a>
                            <div class="col-xxl-6 col-xl-6 col-xs-16 col-lg-5 text-center">
                                <h5 class="gt-margin-top-5 gt-margin-bottom-0">
                                    Profile Created By : Self
                                </h5>
                            </div>
                            <div class="col-xxl-5 col-xxl-5 col-lg-5 col-xs-16 text-center">
                                <h5 class="gt-margin-top-5 gt-margin-bottom-0">
                                    <i class="fa fa-circle text-danger gt-margin-right-10"></i>Online
                                 </h5>
                            </div>
                 	    </div>
                     </div>
                     <div class="gt-panel-body">
                     	 <div class="row gt-border-bottom-smoke-white gt-padding-bottom-15">
                    	  <div class="col-xxl-3 col-xl-3 col-xs-16 col-lg-3">
                                <img src="img/168413723bd00123-world-prem.jpg" class="img-thumbnail">
                          </div>
                          <div class="col-xxl-13 col-xl-13 col-xs-16 col-lg-13 gt-margin-top-10">
                            	<div class="row">
                                	<a href="" class="redirect">
                            		<div class="col-xxl-8 col-xl-8 col-lg-8 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-7 ">Age :</label>
                                        	<span class="col-xs-9">24 years</span>
                                    	</p>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-7">Height :</label>
                                        	<span class="col-xs-9">5ft 5 inch</span>
                                    	</p>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-7">Religion :</label>
                                        	<span class="col-xs-9">Hindu</span>
                                    	</p>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-7">Caste :</label>
                                        	<span class="col-xs-9">Patel</span>
                                    	</p>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-7">Location :</label>
                                        	<span class="col-xs-9">Ahmedabad,India</span>
                                    	</p>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-7">Education :</label>
                                        	<span class="col-xs-9">MBA,MCA,MSc.it</span>
                                    	</p>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-7">Mother Tongue :</label>
                                        	<span class="col-xs-9">Gujarati</span>
                                    	</p>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-7">Occupation :</label>
                                        	<span class="col-xs-9">Software Engineer</span>
                                    	</p>
                                    </div>
                                    
                                    </a>
                                    <div class="col-xxl-16 col-xl-16 col-xs-16">
                                		<p class="row gt-margin-bottom-0">
                                			<label class="col-xs-16 col-xxl-3 col-xl-3 col-lg-16">About Me :</label>
                                        	<span class="col-xs-16 col-xxl-13 col-xl-13 col-lg-16">
                                            	<span class="col-xs-16 gt-profile-me">
                                                	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mauris velit, molestie ut ipsum eget, scelerisque suscipit dolor. Donec sapien velit, ultricies id pulvinar eget, congue ut metus...<a href="">Read More <i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i></a>
                                                </span>
                                            </span>
                                    	</p>
                                    </div>
                                </div>
                            </div>
                         </div>
                         <div class="row">
                         	<div class="col-xxl-4 col-xl-4 col-lg-4 gt-margin-top-10">
                            	<a href="" class="btn btn-default btn-block">
                                	<i class="fa fa-envelope"></i> Send Message
                                </a>
                            </div>
                            <div class="col-xxl-9 col-xl-9 col-lg-12 pull-right">
                            	<div class="row">
                                	<div class="col-xxl-6 col-xl-6 col-xs-16 col-lg-6 gt-margin-top-10">
                            			<a href="" class="btn gt-btn-orange  btn-block">
                                			Send Interest
                                		</a>
                                    </div>
                                    <div class="col-xxl-6 col-xxl-5 col-xl-5 col-lg-5 col-xs-16 gt-margin-top-10">
                                		<a href="" class="btn btn-default btn-block">
                                			<i class="fa fa-ban gt-margin-right-5"></i>Block
                                		</a>
                                    </div>
                                    <div class="col-xxl-6 col-xxl-5 col-xl-5 col-lg-5 col-xs-16 gt-margin-top-10">
                                		<a href="" class="btn btn-default  btn-block">
                                			<i class="fa fa-sort gt-margin-right-5"></i>Shortlist
                                		</a>
                                    </div>
                                </div>
                            </div>
                         </div>
                     </div>
                 </div>