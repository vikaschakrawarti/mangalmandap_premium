							<option value="No Sister" <?php if($DatabaseCo->dbRow->no_of_sisters=='No Sister'){echo "selected";}?>>No Sister</option>
							<option value="1 Sister" <?php if($DatabaseCo->dbRow->no_of_sisters=='1 Sister'){echo "selected";}?>>1 Sister</option>
							<option value="2 Sisters" <?php if($DatabaseCo->dbRow->no_of_sisters=='2 Sisters'){echo "selected";}?>>2 Sisters</option>
							<option value="3 Sisters" <?php if($DatabaseCo->dbRow->no_of_sisters=='3 Sisters'){echo "selected";}?>>3 Sisters</option>
							<option value="4 Sisters" <?php if($DatabaseCo->dbRow->no_of_sisters=='4 Sisters'){echo "selected";}?>>4 Sisters</option>
 							<option value="4 + Sisters" <?php if($DatabaseCo->dbRow->no_of_sisters=='4 + Sisters'){echo "selected";}?>>4 + Sisters</option>