                            <option value="No married brother">No married brother</option>
                            <option value="1 married brother">1 married brother</option>
                            <option value="2 married brothers">2 married brothers</option>
                            <option value="3 married brothers">3 married brothers</option>
                            <option value="4 married brothers">4 married brothers</option>
                            <option value="4 + married brothers">4+ married brothers</option>