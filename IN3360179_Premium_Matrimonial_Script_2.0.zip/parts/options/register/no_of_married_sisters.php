<option value="No married sister">No married sister</option>
                            <option value="1 married sister">1 married sister</option>
                            <option value="2 married sisters">2 married sisters</option>
                            <option value="3 married sisters">3 married sisters</option>
                            <option value="4 married sisters">4 married sisters</option>
                            <option value="4+ married sisters">4+ married sisters</option>