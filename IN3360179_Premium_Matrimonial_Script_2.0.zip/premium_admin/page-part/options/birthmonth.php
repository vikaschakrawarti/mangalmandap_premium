<option value="01" 
                          <?php if(isset($ad[1]) && $ad[1]=='01') {echo "selected";} ?>>Jan
                  </option>
                <option value="02" 
                        <?php if(isset($ad[1]) && $ad[1]=='02') {echo "selected";} ?>>Feb
                </option>
              <option value="03" 
                      <?php if(isset($ad[1]) && $ad[1]=='03') {echo "selected";} ?>>Mar
              </option>
            <option value="04" 
                    <?php if(isset($ad[1]) && $ad[1]=='04') {echo "selected";} ?>>Apr
            </option>
          <option value="05" 
                  <?php if(isset($ad[1]) && $ad[1]=='05') {echo "selected";} ?>>May
          </option>
        <option value="06" 
                <?php if(isset($ad[1]) && $ad[1]=='06') {echo "selected";} ?>>Jun
        </option>
      <option value="07" 
              <?php if(isset($ad[1]) && $ad[1]=='07') {echo "selected";} ?>>Jul
      </option>
    <option value="08" 
            <?php if(isset($ad[1]) && $ad[1]=='08') {echo "selected";} ?>>Aug
    </option>
    <option value="09" 
            <?php if(isset($ad[1]) && $ad[1]=='09') {echo "selected";} ?>>Sep
    </option>
    <option value="10" 
            <?php if(isset($ad[1]) && $ad[1]=='10') {echo "selected";} ?>>Oct
    </option>
    <option value="11" 
            <?php if(isset($ad[1]) && $ad[1]=='11') {echo "selected";} ?>>Nov
    </option>
    <option value="12" 
            <?php if(isset($ad[1]) && $ad[1]=='12') {echo "selected";} ?>>Dec
    </option>																		