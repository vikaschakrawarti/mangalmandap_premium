<footer class="main-footer">       
	Copyright &copy;.&nbsp;<a href="<?php echo $configObj->getConfigName();?>" target="_blank"><?php echo $configObj->getConfigFooter();?></a>.&nbsp;All rights reserved.
</footer>